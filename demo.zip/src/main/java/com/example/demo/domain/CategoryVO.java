package com.example.demo.domain;
import lombok.Data;
public class CategoryVO {


}
